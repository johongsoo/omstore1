package com.web.spring.mainController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.web.spring.mainService.MainService;
import com.web.spring.productsService.ProductsService;
import com.web.spring.vo.MangbungStore;
import com.web.spring.vo.OdungStore;
import com.web.spring.vo.Users;

import jakarta.servlet.http.HttpSession;

@Controller
public class MainController {

	@Autowired(required=false)
	private MainService service;
	@Autowired(required=false)
	private ProductsService service2;
	

	
	
	//http://localhost:8080/odung
	@RequestMapping("odung")
	public String odung() {
		return "WEB-INF\\products\\odung.jsp";
	}
	
	@RequestMapping("userlist")
	public String userlist(Users user, Model model) {
		model.addAttribute("userlist", service.userlist(user));
		return "";
	}
	
	//http://localhost:8080/loginPage
	@GetMapping("loginPage")
	public String loginPage(HttpSession session) {
		session.removeAttribute("users");
		return "WEB-INF\\mainpage\\login.jsp";
	}
	
	//http://localhost:8080/loginPage
	@PostMapping("loginPage")
	public String login(Users users, Model model ,HttpSession session) {
		String msg = "로그인 실패";
		Users loguser = service.login(users); 
		if(loguser!=null) {
			msg = "로그인 성공";
			session.setAttribute("users", loguser);
		}
		model.addAttribute("msg", msg);
		
		return "WEB-INF\\mainpage\\login.jsp";
	}

	//http://localhost:8080/MainPage
	@GetMapping("MainPage")
	public String MainPage(MangbungStore mangbung, OdungStore odung , Model model) {
		model.addAttribute("odung", service2.odunglist(odung));
		model.addAttribute("mangbung", service2.mangbunglist(mangbung));
		return "WEB-INF\\mainpage\\mainpage.jsp";
	}
}
