package com.web.spring.mainDao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.web.spring.vo.Users;

@Mapper
public interface MainDao {
	
	@Select("SELECT *\r\n"
			+ "FROM USERS \r\n"
			+ "WHERE userid LIKE '%'||#{userid}||'%'\r\n"
			+ "AND pwd LIKE '%'||#{pwd}||'%'")
	List<Users> userlist(Users user);
	
	@Select("select *\r\n"
			+ "from users\r\n"
			+ "where userid like '%'||#{userid}||'%'\r\n"
			+ "and pwd like '%'||#{pwd}||'%'")
	Users login(Users users);
}
