CREATE TABLE users(
	userid varchar2(50),
	name varchar2(50),
	pwd varchar2(50),
	email varchar2(50),
	birthdate date,
	address varchar2(100),
	phone varchar2(20),
	rating varchar2(20),
	point number(50)
);