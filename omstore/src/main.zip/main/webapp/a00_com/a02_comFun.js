/**
 * 
 */
function call(){
	alert("공통함수적용")
}